

import java.sql.*;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        try {
            System.out.println("Testing database connection...");
            Connection conn = DatabaseManager.getConnection();
            System.out.println("Connected successfully!");
            
            String sql = "SELECT * FROM Accommodations";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            
            System.out.println("\nAccommodations:");
            while (rs.next()) {
                int id = rs.getInt("accommodation_id");
                String name = rs.getString("name");
                System.out.println(id + ": " + name);
            }
            
            rs.close();
            stmt.close();
            conn.close();
            
            System.out.println("\nLocations:");
            List<String[]> results = DatabaseManager.executeQuery("SELECT * FROM Locations");
            for (String[] row : results) {
                System.out.println(row[0] + ": " + row[1]);
            }
            
        } catch (SQLException e) {
            System.err.println("Database error: " + e.getMessage());
        }
    }
}